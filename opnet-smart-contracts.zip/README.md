# OP_NET Smart Contracts

এই রিপোজিটরিতে ২০টি `OP_20` টোকেন কন্ট্রাক্ট রয়েছে, যেগুলি OP_NET এর অনচেইন টাস্কের জন্য ব্যবহার করা যাবে।

## ব্যবহারবিধি:

1. [Remix IDE](https://remix.ethereum.org/) এ যান।
2. `contracts/` ফোল্ডার থেকে যেকোনো `.sol` ফাইল ওপেন করুন।
3. `Injected Provider - MetaMask` নির্বাচন করে `Deploy` দিন।
4. Constructor-এ Supply দিন (যেমন: `1000000`)।
